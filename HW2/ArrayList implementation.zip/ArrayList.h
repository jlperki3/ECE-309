#ifndef ZYBOOK_ARRAYLIST_H_
#define ZYBOOK_ARRAYLIST_H_

#include <string>
using std::string;

class ArrayList {
public:
   ArrayList();
   ArrayList(const ArrayList&);  // copy constructor
   ArrayList& operator=(const ArrayList&);  // assignment
   ~ArrayList();
   bool empty() const;
   int size() const;
   void push_back(const string&);  // makes a copy of data item
   void push_front(const string&);
   bool pop_back(string& str);  // sets str to a copy of the item removed
   bool pop_front(string& str);
};

#endif